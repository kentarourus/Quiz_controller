const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// publicフォルダ内の静的ファイルを提供
app.use(express.static('public'));

// 初期状態（最大8名まで対応）
let gameState = Array.from({ length: 8 }, (_, i) => ({
    id: i,
    name: `Player ${i + 1}`,
    score: 0,
    penalty: 0,
    status: 'active', // 'active', 'win', 'eliminated'
    active: i < 4 // 初期は4人表示
}));

io.on('connection', (socket) => {
    // 接続したクライアントに現在の状態を送信
    socket.emit('updateState', gameState);

    // コントローラーからの状態更新を受信
    socket.on('updatePlayer', (playerData) => {
        const index = gameState.findIndex(p => p.id === playerData.id);
        if (index !== -1) {
            gameState[index] = playerData;
            io.emit('updateState', gameState); // 全員に同期
        }
    });

    // サウンド再生指示を受信
    socket.on('playSound', (type) => {
        io.emit('playSound', type);
    });

    // 全体リセットを受信
    socket.on('resetAll', () => {
        gameState = gameState.map(p => ({ ...p, score: 0, penalty: 0, status: 'active' }));
        io.emit('updateState', gameState);
    });
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`サーバー起動: http://localhost:${PORT}`);
    console.log(`表示画面: http://localhost:${PORT}/display.html`);
    console.log(`操作画面: http://localhost:${PORT}/controller.html`);
});